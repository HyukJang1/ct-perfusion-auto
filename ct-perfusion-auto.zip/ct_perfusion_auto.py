# CT Perfusion Auto-Analysis Python code (생략, 캔버스 버전 복사)
